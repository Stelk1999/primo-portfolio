//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//FUNZIONI NON MODIFICABILI (SERVONO SOLO PER FAR FUNZIONARE IL CODICE)
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
function getCurrentHour() {

    let UTCHour = new Date().getHours();
    return UTCHour;
};

function getCurrentWeekDay() {
    let weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    let d = new Date();
    return weekday[d.getDay()];
    ;
};

function getRandomValue(items) {
    let item = items[Math.floor(Math.random() * items.length)];
    return item;
};

function generaEta() {
    return Math.floor(Math.random() * 100) + 1;
}

function generaTemperatureSettimanali() {
    let temperature = [];
    for (let i = 0; i < 7; i++) {
        temperature.push(Math.floor(Math.random() * 21) + 20);
    }
    return temperature;
}

function generaStatoSemaforo() {
    let stati = ["Verde", "Giallo", "Rosso"];
    return stati[Math.floor(Math.random() * stati.length)];
}

function generaUtente() {
    return {
        nome: 'Utente' + Math.floor(Math.random() * 100),
        abbonamentoAttivo: Math.random() < 0.5
    };
}
function generaPunteggio() {
    return Math.floor(Math.random() * 101);
}

function generaColori() {
    let colori = ['Blu', 'Verde', 'Rosso', 'Giallo', 'Viola', 'Arancione'];
    return colori.sort(() => 0.5 - Math.random()).slice(0, 3);
}

function scegliColore() {
    let colori = ['Blu', 'Verde', 'Rosso', 'Giallo', 'Viola', 'Arancione'];
    return colori[Math.floor(Math.random() * colori.length)];
}
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------


//ESERCIZI CON LE ESECUZIONI CONDIZIONALI

let arrayRandom = [
    'mela',
    1,
    undefined,
    {nomeProdotto: 'Scarpe', quantita: 1},
    [44, 42, 41, 40],
    'albicocca'
];

let randomElement = getRandomValue(arrayRandom);
// ESERCIZIO 1
// La variabile randomElement recupera un elemento random da arrayRandom
// Consegna:
// Se randomElement è uguale ad undefined esegui un console.log con l'espressione "Elemento indefinito"

// ... Aggiungi qui il tuo codice
if (randomElement === undefined) {
    console.log("Elemento indefinito");
}   

//----------------------------------------------------------------------------------------------------------------------

// ESERCIZIO 2
// La variabile randomElement recupera un elemento random da arrayRandom
// Consegna:
// Se randomElement è uguale ad undefined esegui un console.log con l'espressione "randomElement è indefinito"
// Altrimenti mostra il valore di randomElement in un console.log

// ... Aggiungi qui il tuo codice
if (randomElement === undefined) {
    console.log("RandomElement è indefinito");
} else {
    console.log(randomElement);
}

//----------------------------------------------------------------------------------------------------------------------

let currentHour = getCurrentHour();
// ESERCIZIO 3
// La variabile currentHour recupera l'ora corrente
// Consegna:
// Se currentHour è minore o uguale di 12 esegui un alert() con l'espressione "buongiorno"
// Altrimenti esegui un alert() con l'espressione "buonasera"

// ... Aggiungi qui il tuo codice
if (currentHour <= 12) {
    alert("buongiorno")
} else {
    alert("buonasera")
}

//----------------------------------------------------------------------------------------------------------------------

let currentWeekDay = getCurrentWeekDay();
// ESERCIZIO 4
// La variabile currentHour recupera l'ora corrente
// La variabile currentWeekDay recupera l'attuale giorno della settimana
// Consegna:
// Se currentHour è maggiore di 12 e currentWeekDay è uguale a Wednesday esegui un alert() con l'espressione
// "Buonasera oggi è mercoledì"

// ... Aggiungi qui il tuo codice
if (currentHour > 12 && currentWeekDay === "Wednesday") {
    alert("Buonasera oggi è mercoledì")
}

//----------------------------------------------------------------------------------------------------------------------

let eta = generaEta();
// ESERCIZIO 5:
// la variabile eta è una variabile che genera un'età casuale tra 1 e 100.
// Scrivi una condizione che stampi in console "Maggiorenne" se l'età è maggiore o uguale a 18, altrimenti stampi "Minorenne".

// ... Aggiungi qui il tuo codice
if (eta >= 18) {
    console.log("Maggiorenne");
    
} else {
    console.log("Minorenne");
    
}


let temperaturaSettimanale = generaTemperatureSettimanali();
// ESERCIZIO 6:
// la variabile temperaturaSettimanale genera un array di 7 temperature casuali (una per ogni giorno della settimana), ciascuna tra 20 e 40 gradi.
// Scrivi una condizione che controlli se almeno un giorno ha registrato una temperatura superiore a 30 gradi.
// Se sì, stampa "Settimana calda", altrimenti stampa "Temperature moderate".

// ... Aggiungi qui il tuo codice
if (temperaturaSettimanale.some(temperatura => temperatura > 30)) {
    console.log("Settimana calda");   
}
else {
    console.log("Temperature moderate");
}



let statoSemaforo = generaStatoSemaforo();
// ESERCIZIO 7:
// la variabile statoSemaforo restituisce casualmente uno stato per un semaforo ("Verde", "Giallo", "Rosso").
// Scrivi una condizione che stampi "Vai", "Attenzione" o "Fermati" a seconda del colore.

// ... Aggiungi qui il tuo codice

if (statoSemaforo==="Verde") {
    console.log("Vai");
    
} else if (statoSemaforo==="Giallo") {
        console.log("Attenzione");
        
    } else {
        console.log("Fermati");
        
    }

let utente = generaUtente();
// ESERCIZIO 8:
// la variabile utente restituisce un oggetto con le proprietà `nome` e `abbonamentoAttivo` (vero o falso casualmente).
// Scrivi una condizione che stampi "Accesso consentito" se l'abbonamento è attivo, altrimenti "Accesso negato".

// ... Aggiungi qui il tuo codice

if (utente.abbonamentoAttivo === true) {
    console.log("Accesso consentito");
    
} else {
    console.log("Accesso negato");
    
}

let punteggio = generaPunteggio();
// ESERCIZIO 9:
// la variabile punteggio restituisce un punteggio casuale tra 0 e 100.
// Scrivi una condizione che assegni un livello:
// - "Principiante" se il punteggio è minore di 20
// - "Intermedio" se il punteggio è tra 20 e 50
// - "Esperto" se il punteggio è maggiore di 50


// ... Aggiungi qui il tuo codice

if (punteggio<20) {
    console.log("Principiante");
    
} else if (punteggio <= 50) {
        console.log("Intermedio");
        
    } else {
        console.log("Esperto");
        
}


let palette = generaColori();
let coloreScelto = scegliColore();
// ESERCIZIO 10:
// la variabile palette genera un array di colori   con 3 colori casuali da una lista predefinita.
// la variabile  `coloreScelto` sceglie casualmente un colore da quella stessa lista.
// Scrivi una condizione che verifica se `coloreScelto` è presente nell'array `palette`.
// Se sì, stampa "Colore Presente", altrimenti "Colore non presente".


// ... Aggiungi qui il tuo codice

if (palette.includes(coloreScelto)) {
    console.log("Colore Presente");
    
}
else {
    console.log("Colore non presente");
    
}

