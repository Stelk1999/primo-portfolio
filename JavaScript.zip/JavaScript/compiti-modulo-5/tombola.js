// Disegna la tabella (numeri e basta) della tombola (numeri da 1 a 90) untilizzando un loop
// Se il valore da stampare è un multiplo di 10 vai a capo
// Utilizza il document.write()
// Tag html per andare a capo '<br>'
//document.write('<br>')

// condizione: i % 10 === 0 da mettere nell'if

// RISULTATO ASPETTATO
/*
1 2 3 4 5 6 7 8 9 10
11 12 13 14 15 16 17 18 19 20
21 22 23 24 25 26 27 28 29 30..

*/

for (let i = 1; i <=90; i++) {
        document.write(i + " ")
            if (i % 10 === 0) {
                document.write('<br>')
            }
        }





