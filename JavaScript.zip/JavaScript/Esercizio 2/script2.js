//ESERCIZI VACANZE DI NATALE
// DATI PER GLI ESERCIZI
let veicolo = {
    marca: 'Fiat',
    modello: '500',
    anno: 2018,
    colore: 'rosso',
    proprietario: {
        nome: 'Luca',
        cognome: 'Bianchi',
        patente: 'B123456789',
        indirizzo: {
            via: 'Via Roma',
            numero: 10,
            CAP: '10100',
            citta: 'Torino'
        }
    }
};

// ESERCIZIO 13
// Mostra nella console il valore della proprietà modello dell'oggetto veicolo

console.log(veicolo.modello);

// ESERCIZIO 14
// Mostra nella console il valore della proprietà citta dell'indirizzo del proprietario del veicolo

console.log(veicolo.proprietario.indirizzo.citta);

// ESERCIZIO 15
// Mostra nella console il valore della proprietà patente del proprietario del veicolo

console.log(veicolo.proprietario.patente);

// ESERCIZIO 16
// Aggiungi la proprietà targa all'oggetto veicolo e assegnale un valore a tuo piacimento
// Mostra la nuova proprietà nella console

veicolo.targa = 'dz657xv';
console.log(veicolo.targa.toUpperCase()); //ho aggiunto la funzione toUppercase come di norma per le targhe

// ESERCIZIO 17
// Modifica il colore del veicolo e poi mostra l'intero oggetto veicolo nella console

veicolo.colore = 'verde';
console.log(veicolo);

// ESERCIZIO 18
// Mostra nella console la lunghezza della stringa rappresentata dalla proprietà marca del veicolo

console.log(veicolo.marca.length);

// ESERCIZIO 19
// Concatena e mostra nella console le stringhe rappresentate dalle proprietà nome e cognome del proprietario del veicolo

console.log(veicolo.proprietario.nome + ' ' + veicolo.proprietario.cognome);

// ESERCIZIO 20
// Cerca la posizione del carattere 'A' nella stringa soggetto

let saluto = 'Ciao';
let soggetto = 'Amico';
console.log(soggetto.indexOf('A'));

// ESERCIZIO 21
// Converti la stringa saluto in maiuscolo

saluto = saluto.toUpperCase();
console.log(saluto.toUpperCase());

// ESERCIZIO 22
// Converti la stringa soggetto in minuscolo

soggetto = soggetto.toLowerCase(); 
console.log(soggetto.toLowerCase());

// ESERCIZIO 23
// Sostituisci la parola 'amico' con 'Compagno' nella stringa soggetto

soggetto = soggetto.replace("amico", "Compagno");
console.log(soggetto);

// ESERCIZIO 24
// Aggiungi una proprietà peso all'oggetto veicolo e assegnale un valore numerico
// Mostra la proprietà peso nella console

veicolo.peso = 200;
console.log(veicolo.peso);

// ESERCIZIO 25
// Mostra nella console il tipo di dato della proprietà anno del veicolo

console.log(typeof veicolo.anno);

 // ESERCIZIO 26 (DA NON FARE)
// Mostra nella console se il colore del veicolo è 'blu'

if (veicolo.colore === 'blu') {
    console.log('Sì, il veicolo è blu');
}
else {
    console.log('No, il veicolo non è blu');
}

 // ESERCIZIO 27
// Incrementa l'anno del veicolo di 1 e poi mostra l'intero oggetto veicolo nella console

veicolo.anno++;
console.log(veicolo);


// ESERCIZIO 28
// Mostra nella console la concatenazione delle proprietà via e numero dell'indirizzo del proprietario del veicolo

console.log(veicolo.proprietario.indirizzo.via + ' ' + veicolo.proprietario.indirizzo.numero);

// ESERCIZIO 29
// Sostituisci la marca del veicolo con 'Toyota' e mostra l'intero oggetto veicolo nella console

veicolo.marca = 'Toyota';
console.log(veicolo);

// ESERCIZIO 30
// Mostra nella console se il CAP dell'indirizzo del proprietario del veicolo inizia con '10'

if (veicolo.proprietario.indirizzo.CAP.startsWith('10')) {
    console.log("Sì, il CAP inizia con '10'");
    
} else {
    console.log("No, il Cap non inizia con '10'");
    
};

 // ESERCIZIO 31
// Mostra nella console se il modello del veicolo contiene la parola '500'

if (veicolo.modello.includes('500')) {
    console.log("Sì, il modello contiene la parola '500'");
    
} else {
    console.log("No, il modello non contiene la parola'500'");
    
}
// ESERCIZIO 32
// Converti in maiuscolo la proprietà cognome del proprietario del veicolo

veicolo.proprietario.cognome = veicolo.proprietario.cognome.toUpperCase();
console.log(veicolo.proprietario.cognome);

// ESERCIZIO 33
// Mostra nella console l’ultima lettera della proprietà nome del proprietario del veicolo

console.log(veicolo.proprietario.nome.slice(-1));

// ESERCIZIO 34
// Trasforma la proprietà citta dell’indirizzo del proprietario in maiuscolo e mostra il nuovo valore nella console

veicolo.proprietario.indirizzo.citta = veicolo.proprietario.indirizzo.citta.toUpperCase();
console.log(veicolo.proprietario.indirizzo.citta);

// ESERCIZIO 35
// Mostra nella console la somma delle lunghezze delle stringhe saluto e soggetto

console.log(saluto.length + soggetto.length);

// ESERCIZIO 36
// Estrai i primi 4 caratteri della proprietà patente del proprietario e mostrali nella console
// (converti la stringa patente in minuscolo prima di estrarre)

veicolo.proprietario.patente = veicolo.proprietario.patente.toLowerCase();
console.log(veicolo.proprietario.patente.substring(0,4));


// ESERCIZIO 37
// Mostra nella console la concatenazione di nome e patente del proprietario separati da un trattino (-)

console.log(veicolo.proprietario.nome + "-" + veicolo.proprietario.patente);

// ESERCIZIO 38
// Mostra nella console la concatenazione delle proprietà via e citta dell’indirizzo del proprietario del veicolo,
// separandole con una virgola

console.log(veicolo.proprietario.indirizzo.via + ',' + ' ' + veicolo.proprietario.indirizzo.citta);

// ESERCIZIO 39
// Sostituisci gli ultimi 3 caratteri della proprietà patente con 'XXX' e mostra il risultato nella console

veicolo.proprietario.patente = veicolo.proprietario.patente.slice(0, -3) + 'XXX';
console.log(veicolo);

// ESERCIZIO 40
// Trasforma la proprietà cognome del proprietario in minuscolo e concatenala con la proprietà nome,
// poi mostra il risultato nella console

veicolo.proprietario.cognome = veicolo.proprietario.cognome.toLowerCase();
console.log(veicolo.proprietario.cognome + ' ' + veicolo.proprietario.nome);

// ESERCIZIO 41
// Trasforma la proprietà marca del veicolo in minuscolo e mostra la nuova marca nella console

veicolo.marca = veicolo.marca.toLowerCase();
console.log(veicolo.marca);

// ESERCIZIO 42
// Aggiungi un punto esclamativo alla fine della stringa saluto e mostra il risultato nella console

saluto = saluto + '!';
console.log(saluto);

// ESERCIZIO 43
// Sostituisci il carattere 'o' con '*' nella proprietà colore del veicolo e mostra il risultato nella console
//ho riassegnato il valore rosso alla proprietà colore per sostituire il carattere 'o'

veicolo.colore = 'rosso';
veicolo.colore = veicolo.colore.replaceAll('o', '*');
console.log(veicolo);

// ESERCIZIO 44
// Mostra nella console la lunghezza della stringa ottenuta concatenando nome e cognome del proprietario
// (separati da uno spazio)

let NomeCompleto = veicolo.proprietario.nome + ' ' + veicolo.proprietario.cognome;
console.log(NomeCompleto.length);

// ESERCIZIO 45
// Aggiungi una nuova proprietà descrizione all'oggetto veicolo contenente la concatenazione di marca e modello
// (separate da uno spazio) e mostra la nuova proprietà nella console

veicolo.descrizione = veicolo.marca + ' ' + veicolo.modello;
console.log(veicolo.descrizione);
console.log(veicolo);

