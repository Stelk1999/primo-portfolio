//VERIFICA
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//MODULO 2 - OGGETTI
let prodotto = {
    nome: 'Televisore',
    prezzo: 12,
    dimensioni: {
        larghezza: 102,
        altezza: 76,
        diagonale: 127
    }
}


// Esercizio 1
document.write(prodotto.prezzo);
//Accedo alla proprietà dell'oggetto con la dot notation partendo dal nome dell'oggetto, Stampo in html grazie a "document.write()"

// Esercizio 2
prodotto.nome = prodotto.nome.toUpperCase();
console.log(prodotto);
prodotto.colore = 'rosso';
document.write(`<br>`);
document.write(prodotto.colore);
//per modificare la proprietà di un oggetto dobbiamo richiamarla e con l'operatore di assegnazione applicare alla stessa la funzione "toUpperCase()".




//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//MODULO 3 - ARRAY
let arrayFrutta = [
    'Banana',
    'Mela',
    'Pera',
    'Mango',
    'Kiwi'
];

// Esercizio 3
document.write(`<br>`);
document.write(arrayFrutta[arrayFrutta.length-2] + " - " + arrayFrutta[arrayFrutta.length-1] + `<br>`)
//Versione alternativa
//document.write(arrayFrutta[3] + arrayFrutta[4]);//
//Per effettuare un accesso diretto ad un elemento di un array richimiano il nome dell'array e tra parentesi quadre inseriamo l'indice preciso oppure con .length meno 1 accediamo automaticamente all'ultimo elemento dell'array, con meno 2 al penultimo etc.

// Esercizio 4
arrayFrutta.pop();
arrayFrutta.push("Fragola", "Arancia");
console.log(arrayFrutta);
//Ho utilizzato prima il metodo "pop()" per rimuovere l'ultimo elemento dell'array. Per aggiungere 2 nuovi elementi ho usato il metodo "push()" che aggiunge nuovi elementi alla fine del'array come da consegna.Ho usato questi metodi perchè in questo caso mi sembrava il modo più veloce ed efficiente per rispondere alla traccia dell'esercizio.




//------------------------------------------------------------------------------------------------------------------------
// Esercizio 5

let dbUtenti1 = [
    { nomeUtente: 'Utente 1', password: 'password111' },
    { nomeUtente: 'Utente 2', password: 'ciaomondo123' },
    { nomeUtente: 'Utente 3', password: 'password_difficile' },
    { nomeUtente: 'Utente 4', password: 'ciaociaociao' },
]

dbUtenti1.forEach(function(utente){
    document.write(utente.nomeUtente + " " + utente.password + `<br>`);
})
//il forEach è un ciclo che itera su ogni elemento dell'array. Si inserisce un parametro, in questo caso "utente", di cui il nome è arbitrario, possiamo scegliere quello che vogliamo. Quest'ultimo corrisponderà automaticamente ad ogni elemento dell'array.
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//MODULO 4 - LOOP

// Esercizio 6
for (let i = 0; i <= 90; i+=9){
   document.write(i + " - ");
} 

//Ho scelto il ciclo for e per verificare la fine del ciclo ho impostato l'indice "i" <= a 90 che è la fine della tabellina del nove, in questo modo il ciclo si fermerà a 90. l"inizio del ciclo parte da 0 perchè incluso nella tabellina. ad ogni giro del ciclo ad "i" viene sommato 9.
//------------------------------------------------------------------------------------------------------------------------


// Esercizio 7

let dbUtenti2 = [
    { nomeUtente: 'Utente 1', password: 'password111' },
    { nomeUtente: 'Utente 2', password: 'ciaomondo123' },
    { nomeUtente: 'Utente 3', password: 'password_difficile' },
    { nomeUtente: 'Utente 4', password: 'ciaociaociao' },
]


for (let i = 0; i < dbUtenti2.length; i++) {
    document.write(`<br>` + dbUtenti2[i].nomeUtente + " - " + dbUtenti2[i].password)
}
//Itero sull'array di oggetti con un ciclo for che si ferma quando finisce l'array. Per ottenere le due proprietà durante ogni giro richiamo il nome dell'array indicizzato [i] in modo da stampare solo l'elemento corrispondente a quel giro, con la dot notatio specifico quale elemento dell'array voglio visualizzare.
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//MODULO 5 - CONDIZIONI

function customGetGrade() {
    return Math.floor(Math.random() * 101);
}
let voto = customGetGrade();

if (customGetGrade()>60) {
    document.write(`<br>` + "La verifica è andata bene")
} else {
    document.write(`<br>` + "La verifica è andata male")
}

//La logica è la seguente: se il numero resituito da "customGetGrade()" è maggiore di 60 allora stamperò a schermo la prima frase, altrimenti stamperò automaticamente la seconda frase che si applchierà ogni volta che il numero pescato non è maggiore di 60.
//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//PROGETTAZIONE LIBERA

// Esercizio 9

let dbUtenti3 = [
    { ID: 1, nomeUtente: 'Utente 1', password: 'password111', ruolo: 'subscriber' },
    { ID: 2, nomeUtente: 'Utente 2', password: 'ciaomondo123', ruolo: 'editor' },
    { ID: 3, nomeUtente: 'Utente 3', password: 'password_difficile', ruolo: 'editor' },
    { ID: 4, nomeUtente: 'Utente 4', password: 'ciaociaociao', ruolo: 'admin' },
]

for (let i=0; i<dbUtenti3.length; i++){
    if (dbUtenti3[i].ruolo === 'editor' && dbUtenti3[i].ID > 2){
        document.write(`<br>` + dbUtenti3[i].nomeUtente)

    }}

//Ho utilizzato un ciclo for per iterare su tutti gli elementi dell'array, Poi per ogni elemento ho verificato la condizione necessaria per stampare l'utente corretto e cioè che il suo ruolo e allo stesso tempo il suo ID devono essere rispettivamente "editor" e maggiore di 2.

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//BONUS:DEBUG
let smartphone = {
    marca: 'Samsung',
    modello: 'Galaxy S21',
    prezzo: 899,
    specifiche: {
        schermo: '6.2 pollici',
        processore: 'Exynos 2100',
        memoria: '8GB RAM',
        storage: '128GB'
    }
}

//codice errato:
//console.log(smartphone.processore + ' ' + smarphone.memoria)
//codice corretto:
console.log(smartphone.specifiche.processore + ' ' + smartphone.specifiche.memoria);

//L'errore stava nel richiamare una proprietà che era dentro all'oggetto "specifiche", con la dot notation bisognava andare "più a fondo" per andare a trovare il valore che ci interessava. una sorta di gerarchia delle proprietà dentro gli oggetti.