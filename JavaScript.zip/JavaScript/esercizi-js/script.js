//DATI PER GLI ESERCIZI
// Gli output degli esercizi andranno mostrati nella console

let utente = {
    nome: 'Mario',
    cognome: 'Rossi',
    email: 'mariorossi@cnosfap.local',
    username: 'mariorossi',
    indirizzo: {
        via: 'Via Garibaldi',
        numero: 15,
        CAP: '00100',
        citta: 'Roma'
    }
};

// ESERCIZIO 1
//Mostra nella console il valore della proprietà nome dell'oggetto utente

console.log(utente.nome);

// ESERCIZIO 2
//Mostra nella console il valore della proprietà indirizzo dell'oggetto utente

console.log(utente.indirizzo);

// ESERCIZIO 3
//Mostra nella console il valore della proprietà CAP dell'oggetto utente

console.log(utente.indirizzo.CAP);

// ESERCIZIO 4
//Crea la proprietà compleanno e assegnale un valore a tuo piacimento mantenendo invariata la tipologia di dato
//Successivamente mostra la proprietà nella console.

utente.compleanno = '19 maggio 1999';
console.log(utente.compleanno);

// ESERCIZIO 5
//Sostituisci tutte le proprietà dell'oggetto utente con dei valori a tuo piacimento
//Successivamente mostra l'intero oggetto nella console

utente.nome = 'Valerio';
utente.cognome = 'Indiveri';
utente.email = 'valerio.indi@gmail.com';
utente.username = 'vale_indi';
utente.indirizzo.via = 'Via del porto';
utente.indirizzo.numero = '40';
utente.indirizzo.CAP = '40122';
utente.indirizzo.citta = 'Bologna';
console.log(utente);

// ESERCIZIO 6
//Mostra nella console la lunghezza della stringa rappresentata dalla variabile testo

let testo = 'Ciao'
console.log(testo.length);

// ESERCIZIO 7
//Mostra nella console le stringhe testo e testo2 utilizzando entrambi i metodi di concatenazione

let stringa1 = 'Ciao';
let stringa2 = 'Mondo';
console.log(stringa1 + stringa2);
stringa1 += stringa2;
console.log(stringa1);

// ESERCIZIO 8
//Cerca la posizione del carattere 'i' nella stringa testo

console.log(testo.indexOf('i'));

// ESERCIZIO 9
//Converti la stringa testo in maiuscolo

console.log(testo.toUpperCase());

// ESERCIZIO 10
//Converti la stringa testo in minuscolo

console.log(testo.toLowerCase());

// ESERCIZIO 11
//Cerca la parola 'Mondo' nella stringa testo e sostituiscila con la parola 'JavaScript'

let testo2 = 'Ciao Mondo';
console.log(testo2.replace('Mondo', 'JavaScript'));

// ESERCIZIO 12
//Converti in maiuscolo la proprietà username dell'oggetto utente.

console.log(utente.username.toUpperCase());

