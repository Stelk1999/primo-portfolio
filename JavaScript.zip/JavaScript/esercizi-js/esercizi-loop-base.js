// ESERCIZIO 1
// Mostra nella console il risultato dell'espressione: 5 === 5
console.log(5 === 5);


// ESERCIZIO 2
// Mostra nella console il risultato dell'espressione: 10 > 7
console.log(10 > 7);



// ESERCIZIO 3
// Mostra nella console il risultato dell'espressione: "ciao" === "ciao"
console.log("ciao" === "ciao");


//LOOP-------------------------------------------------------------------------------------------

// ESERCIZIO 1
// Usa un ciclo for per mostrare i numeri da 1 a 5 nella console
for (let i = 1; i <= 5; i++) {
    console.log(i);
}
// ESERCIZIO 2
// Usa un ciclo while per mostrare i numeri da 1 a 5 nella console
let ind = 1;
while (ind<=5){
    console.log(ind);
    ind++;
}

// ESERCIZIO 3
// Usa un ciclo for per iterare su un array ["a", "b", "c"] e mostra ogni elemento nella console
let array = ["a","b","c"];
for (let i = 0; i < array.length; i++){
    console.log(array[i]);
}


// ESERCIZIO 4
// Usa un ciclo while per contare all'indietro da 5 a 1 e mostra ogni numero nella console
let indi = 5;
while (indi>=1){
    console.log(indi);
    indi--;
}


// ESERCIZIO 5
// Crea un array "numeri" con i valori [10, 20, 30]
// Usa un ciclo for per mostrare ogni numero moltiplicato per 2 nella console
let numerii = [10, 20, 30];
for (let i = 0; i < numerii.length; i++){
    console.log(numerii[i] * 2);
}


// ESERCIZIO 6
// Usa un ciclo for per calcolare la somma dei numeri da 1 a 10 e mostra il risultato nella console
let sommaa = 0;
for (let i = 1; i <= 10; i++){
    sommaa += i;
}
console.log(sommaa);

// ESERCIZIO 7
// Crea un array "parole" con i valori ["uno", "due", "tre"]
// Usa un ciclo while per mostrare ogni elemento dell'array nella console
let parole = ["uno", "due", "tre"];
let i = 0;
while (i < parole.length){
    console.log(parole[i]);
    i++;
}