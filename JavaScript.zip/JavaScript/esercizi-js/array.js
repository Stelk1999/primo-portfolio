
// ESERCIZIO 1
// Crea un array "frutti" con questi elementi: "Mela", "Banana", "Pera", "Kiwi"
// Mostra la lunghezza dell'array "frutti" nella console
let frutti = ['Mela', 'Banana', 'Ciliegia', 'Pera', 'Kiwi'];
console.log(frutti.length);

// ESERCIZIO 2
// Mostra nella console il secondo elemento dell'array "frutti"

console.log(frutti[1]);


// ESERCIZIO 3
// Mostra nella console il numero di lettere del primo frutto nell'array "frutti"

console.log(frutti[0].length);

// ESERCIZIO 4
// Verifica se "frutti" è un array
// Mostra il risultato della verifica nella console

console.log(Array.isArray(frutti));


// ESERCIZIO 5
// Converti l'array "frutti" in una stringa, separando gli elementi con un trattino '-'
// Mostra la stringa risultante nella console

frutti = frutti.join(" - ");
console.log(frutti);


// ESERCIZIO 6
// Crea un array "numeri" con questi elementi: 1, 2, 3, 4, 5
// Calcola la somma del primo e dell'ultimo elemento dell'array "numeri"
// Mostra il risultato della somma nella console

let numeri = [1,2,3,4,5];
let somma = numeri[0] + numeri [numeri.length - 1];
console.log(somma);


// ESERCIZIO 7
// Aggiungi "Arancia" all'array "frutti"
// Mostra l'array "frutti" aggiornato nella console

frutti = frutti.split(' - ');
frutti.push('Arancia');
console.log(frutti);


// ESERCIZIO 8
// Rimuovi l'ultimo elemento dell'array "frutti" e mostralo nella console

frutti.pop(); //soluzione 1
let UltimoElemento = frutti.splice(frutti.length - 1, 1); //soluzione 2
console.log(UltimoElemento);


// ESERCIZIO 9
// Usa slice() per copiare i primi due elementi di "frutti" in un nuovo array
// Mostra il nuovo array nella console

let NuovoArray = frutti.slice(0,2);
console.log(NuovoArray);


// ESERCIZIO 10
// Crea un array "verdure" con questi elementi: "Carota", "Pomodoro", "Cipolla"
// Usa forEach() per mostrare ogni elemento di "verdure" nella console

let verdure = ["carota","pomodoro", "cipolla"];
verdure.forEach(function(verdura){
    console.log(verdura);
})


// ESERCIZIO 11
// Usa forEach() per mostrare nella console il titolo e l'autore di ogni libro in formato "Titolo - Autore"
// Usa nuovamente forEach() per aggiungere 10 a ogni proprietà "quantità"
// Alla fine dovrai controllare che tutte le quantità siano aumentate all'interno dell'oggetto
let libreria = [
    { titolo: "Il nome della rosa", autore: "Umberto Eco",quantita:2 },
    { titolo: "1984", autore: "George Orwell",quantita:1 },
    { titolo: "Il grande Gatsby", autore: "F. Scott Fitzgerald",quantita:6 }
];

libreria.forEach(function(libro,index) {
    console.log(libro);
    console.log(libro.titolo + " - " + libro.autore);
})

libreria[0].quantita = libreria[0].quantita+10;
libreria[1].quantita = libreria[1].quantita+10;
libreria[2].quantita = libreria[2].quantita+10;



libreria.forEach(libro=>{
libro.quantita = libro.quantita + 10;
})
console.log(libreria);

