let arrayFrutta = [
    'mela',
    'pera',
    'arancia',
    'kiwi',
    'melone'
];
let arrayNumerico = [10, 20, 30, 40, 50, 60, 70, 80, 90]



let carrello = [
    { nomeProdotto: 'insalata', quantità: 2 },
    { nomeProdotto: 'melanzane', quantità: 4 },
    { nomeProdotto: 'pomodori', quantità: 5 },
    { nomeProdotto: 'broccoli', quantità: 1 },
]

// ESERCIZIO 1
// esegui un console.log per ogni elemento di arrayFrutta dove mostri il valore dell'elemento corrente



// ESERCIZIO 2
// esegui un console.log per ogni elemento di arrayFrutta dove mostri l'indice dell'elemento corrente

// ESERCIZIO 3
// esegui un console.log per ogni elemento di arrayMisto dove mostri la tipologia di dato del valore dell'elemento corrente (typeof)

// ESERCIZIO 4
// converti in stringhe tutti gli elementi di arrayNumerico
//succesivamente mostra l'intero array nella console

    arrayNumerico.forEach((numero, indice) => {
        arrayNumerico[indice] = numero.toString();
        
    })
    console.log(arrayNumerico);
    

// ESERCIZIO 5
// riconverti in intero tutti gli elementi di arrayNumerico (ora sono delle stringhe)
// aggiungi il valore 1 ad ogni elemento dell'array
//succesivamente mostra l'intero array nella console

arrayNumerico.forEach((numero, indice)=> {
    arrayNumerico[indice] = parseInt(numero);
})
console.log(arrayNumerico);

// ESERCIZIO 6
// aggiungi la stringa 'Ciao Mondo' ad ogni elemento di arrayFrutta
//successivamente mostra l'intero array nella console


// ESERCIZIO 7
// Converti in maiuscolo tutti i valori associati alla chiave nomeProdotto all'interno degli oggetti presenti nell'array carrello
//successivamente mostra l'intero array nella console


// ESERCIZIO 8
// Aggiungi il valore 10 a tutti i valori associati alla chiave quantità all'interno degli oggetti presenti nell'array carrello
//successivamente mostra l'intero array nella console
