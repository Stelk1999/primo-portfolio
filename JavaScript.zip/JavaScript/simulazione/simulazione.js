//VERIFICA
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//MODULO 2 - OGGETTI
let smartphone = {
    marca: 'Samsung',
    modello: 'Galaxy S21',
    prezzo: 899,
    specifiche: {
        schermo: '6.2 pollici',
        processore: 'Exynos 2100',
        memoria: '8GB RAM',
        storage: '128GB'
    }
}


// Esercizio 1
document.write(smartphone.marca + " " + smartphone.modello + `<br>`);
//ho usato document.write() per stampare a schermo sul foglio html. Per accedere alle proprietà dell'oggetto ho usato la dot notation (nomeoggetto.proprietà).


// Esercizio 2
smartphone.prezzo = smartphone.prezzo / 2;
console.log(smartphone.prezzo);
smartphone.colore = 'rosso';
document.write(smartphone.colore + `<br>`);
// per modificare una proprietà basta riassegnarle un nuovo valore.Per aggiungerla si usa sempre la dot notation con il nome della nuova proprietà, poi le assegniamo un valore con "=".


//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//MODULO 3 - ARRAY
let libri = [
    'Il Signore degli Anelli',
    'Harry Potter',
    'Il Codice Da Vinci',
    'Orgoglio e Pregiudizio',
    'Il Piccolo Principe'
];

// Esercizio 3
document.write(libri[0]," , ", (libri[libri.length-1] + `<br>`));
//il primo elemento di un array è sempre zero. l'ultimo elemento lo troviamo con la lunghezza dell'array meno 1.



// Esercizio 4

libri.pop();
libri.push("La Divina Commedia", "I Promessi Sposi")
console.log(libri);
//si usa .pop() per rimuovere l'ultimo elemento di un array. si usa .push() per aggiungere alla fine di un array degli elementi che vogliamo inserendoli come parametri tra "".



//------------------------------------------------------------------------------------------------------------------------
// Esercizio 5

let videogiochi = [
    { titolo: 'The Legend of Zelda', genere: 'Avventura' },
    { titolo: 'Super Mario Bros', genere: 'Piattaforma' },
    { titolo: 'Minecraft', genere: 'Sandbox' },
    { titolo: 'The Witcher 3', genere: 'RPG' },
    { titolo: 'FIFA 21', genere: 'Sport' }
];


   
videogiochi.forEach(function(videogioco){
    
    document.write(videogioco.titolo + " - ");
    document.write(videogioco.genere);
    document.write(`<br>`);
 })


//------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//MODULO 4 - LOOP

// Esercizio 6
for(let i=10; i<=20; i++) {
    document.write([i + " "]);
}

//Ho scelto il for che inizia da 10 come da consegna e finisce quando l'index è maggiore di 20. per ogni giro scrivo sul foglio html il valore 'i' che aumenterà ogni volta di 1.


// Esercizio 7

let persone = [
    { nome: 'Marco', eta: 25 },
    { nome: 'Luigi', eta: 34 },
    { nome: 'Anna', eta: 29 },
    { nome: 'Francesca', eta: 32 },
    { nome: 'Giovanni', eta: 45 }
];

for(let i=0; i<persone.length; i++){
    document.write(`<br>` + persone[i].nome + ": " + persone[i].eta + " ");   
}

//uso un for per iterare su ogni elemento dell'array e ottengo le due proprietà richiamandole con la dot notation, utilizzo l'indice [i] dentro le quadre dopo il nome dell'array per indicare che le proprietà che mi servono sono quelle corrispondenti all'indice in corso.
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//MODULO 5 - CONDIZIONI

function generaTemperatura() {
    return Math.floor(Math.random() * 41) - 5;
}
let temperaturaCasa = generaTemperatura();

if(temperaturaCasa < 18){
    console.log("Accendi il riscaldamento")
} else if ( temperaturaCasa > 28) {
    console.log("Accendi l'aria condizionata");
    
} else {
    console.log("Temperatura confortevole");
    
}


//se la temperatura è minore di 18 allora stampo, altrimenti se è maggiore di 28 stampo altro altrimenti stampo altro ancora.

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//PROGETTAZIONE LIBERA

// Esercizio 9

let prodotti = [
    { nome: 'Smartphone', categoria: 'elettronica', prezzo: 299 },
    { nome: 'Laptop', categoria: 'elettronica', prezzo: 899 },
    { nome: 'Frullatore', categoria: 'elettrodomestici', prezzo: 49 },
    { nome: 'Tablet', categoria: 'elettronica', prezzo: 199 },
    { nome: 'Smartwatch', categoria: 'elettronica', prezzo: 149 }
];

for (let i=0; i<prodotti.length; i++){
    if (prodotti[i].categoria === 'elettronica' && prodotti[i].prezzo < 500){
        document.write(`<br>` + prodotti[i].nome)

    }}

// ho scelto di iterare sull'array confrontando per ogni giro se la proprietà categoria fosse 'elettronica' e allo stesso tempo la proprietà prezzo fosse minore di 500 con un operatore logico "&&", entrambe le condizioni devono essere vere per realizzarsi. Quindi stamperemo solo i prodotti che rispettano la condizione data. ho usato un for per mia migliore comprensione logica.

//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------

//BONUS:DEBUG

let persona = {
    nome: "Mario",
    eta: "18"
};

if (persona.eta >= 18) {
    console.log("Sei maggiorenne");
    
} else {
    console.log("Sei minorenne");
    
}

//l'errore stava nell'operatore di confronto, ho sostituito "=" con ">=" per verificare se eta è maggiore o uguale a 18 (includendo anche quest'ultimo). Se dovessi solo verificare se l'età è maggiore di 18 avrei utilizzato solo il maggiore ">".


let persona2 = {
    nome: "Mario",
    eta: "18"
};

if (persona.eta > 18) {
    console.log("Sei maggiorenne");
    
} else {
    console.log("Hai 18 anni o meno");
    
}