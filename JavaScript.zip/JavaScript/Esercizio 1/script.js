//Esercizio 1
//1.1
let prova = 10;
console.log(prova);

//1.2
let variabile1 = 5;
let variabile2 = 3;
console.log(variabile1 + variabile2);

//1.3
let variabile3 = 100;
console.log(variabile3 * 2);

//1.4
console.log(50/5);

//Esercizio 2
//2.1
let variabile4 = 'Ciao!';
console.log(variabile4);

//2.2
let variabile5 = 'Buongiorno';
let variabile6 = 'Mondo';
console.log(variabile5 + variabile6);

//2.3
let mioNome = 'Valerio Indiveri';
console.log(mioNome);

//Esercizio 3
//3.1
let niente = null;
console.log(niente);

//3.2
let varCasuale;
console.log(varCasuale);

//3.3
let numero = 10;
numero = null;
console.log(numero);

//Esercizio 4
//4.1
let varBool = true;
console.log(varBool);

//4.2
let varBool2 = false;
console.log(varBool2);

let oggettoTest = {
    marca: 'Fiat',
    modello: 'Punto',
    cavalli: 120,
    colore: 'Bianco',
    allesitmenti: {
        base: 'base',
        avanzato:'Abarth'
    },
    mantenimentoCorsia : function() {
        //Quando esco dalle linee la macchina deve riportarmi in carreggiata
    }
}